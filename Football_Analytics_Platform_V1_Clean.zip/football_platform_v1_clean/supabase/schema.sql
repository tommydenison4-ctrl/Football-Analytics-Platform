-- Football Analytics Platform v1 clean schema
-- Safe reset. This deletes old prototype tables if they exist.
drop table if exists public.charted_plays cascade;
drop table if exists public.plays cascade;
drop table if exists public.projects cascade;

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  season text,
  opponent text,
  source_filename text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.plays (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  row_index integer not null,
  play_key text,
  pff_offteam text,
  pff_defteam text,
  pff_gameid text,
  pff_playid text,
  pff_gsisplayid text,
  pff_sortorder text,
  pff_week text,
  raw jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(project_id, row_index)
);

create table public.charted_plays (
  id uuid primary key default gen_random_uuid(),
  play_id uuid not null references public.plays(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  chart_formation text,
  fz_advantage text check (fz_advantage in ('Field','Boundary','Box','MOF') or fz_advantage is null),
  fz_attacked text check (fz_attacked in ('Field','Boundary','Box','MOF') or fz_attacked is null),
  advantage_attacked integer generated always as (
    case when fz_advantage is not null and fz_attacked is not null and fz_advantage = fz_attacked then 1 else 0 end
  ) stored,
  flagged boolean not null default false,
  skipped boolean not null default false,
  notes text,
  updated_at timestamptz not null default now(),
  unique(play_id)
);

create index plays_project_idx on public.plays(project_id);
create index plays_team_idx on public.plays(pff_offteam, pff_defteam);
create index charted_project_idx on public.charted_plays(project_id);

alter table public.projects enable row level security;
alter table public.plays enable row level security;
alter table public.charted_plays enable row level security;

-- Prototype policy: open access with anon key. For private production use, add Supabase Auth and user_id columns later.
create policy "public_projects_all" on public.projects for all using (true) with check (true);
create policy "public_plays_all" on public.plays for all using (true) with check (true);
create policy "public_charted_all" on public.charted_plays for all using (true) with check (true);
