import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import Papa from 'papaparse'
import * as XLSX from 'xlsx'
import { supabase, supabaseEnabled } from './supabaseClient.js'
import './style.css'

const ZONES = ['Field','Boundary','Box','MOF']
const FORM_BASES = ['10','11','12','13','20','21','22','23','30','31','32','33','40','41','42','43']
const TAGS = ['B','T','TT','WS','WW','DT','DW']
const PFF_KEYS = ['pff_OFFTEAM','pff_DEFTEAM','pff_GAMEID','pff_PLAYID','pff_GSISPLAYID','pff_SORTORDER','pff_WEEK']

function norm(row, key) { return row[key] ?? row[key?.toLowerCase?.()] ?? row[key?.toUpperCase?.()] ?? '' }
function playKey(row, i) { return String(norm(row,'pff_PLAYID') || norm(row,'pff_GSISPLAYID') || norm(row,'pff_SORTORDER') || i+1) }
function csvEscape(v) { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g,'""') + '"' : s }

function App(){
  const [projects,setProjects]=useState([])
  const [project,setProject]=useState(null)
  const [plays,setPlays]=useState([])
  const [charts,setCharts]=useState({})
  const [idx,setIdx]=useState(0)
  const [filterTeam,setFilterTeam]=useState('')
  const [filterMode,setFilterMode]=useState('either')
  const [formation,setFormation]=useState('')
  const [fzAdv,setFzAdv]=useState('')
  const [fzAtk,setFzAtk]=useState('')
  const [status,setStatus]=useState(supabaseEnabled ? 'Online database connected.' : 'Local demo mode. Add Supabase env vars to save online.')

  useEffect(()=>{ loadProjects() },[])

  async function loadProjects(){
    if(!supabaseEnabled){
      const local = JSON.parse(localStorage.getItem('fp_projects')||'[]')
      setProjects(local); return
    }
    const {data,error}=await supabase.from('projects').select('*').order('updated_at',{ascending:false})
    if(error) setStatus(error.message); else setProjects(data||[])
  }

  async function selectProject(p){
    setProject(p); setIdx(0); setFilterTeam(''); setStatus('Loading project...')
    if(!supabaseEnabled){
      const local = JSON.parse(localStorage.getItem('fp_'+p.id)||'{}')
      setPlays(local.plays||[]); setCharts(local.charts||{}); setStatus('Loaded local project.'); return
    }
    const {data:playRows,error:e1}=await supabase.from('plays').select('*').eq('project_id',p.id).order('row_index')
    if(e1){setStatus(e1.message);return}
    const {data:chartRows,error:e2}=await supabase.from('charted_plays').select('*').eq('project_id',p.id)
    if(e2){setStatus(e2.message);return}
    const map={}; (chartRows||[]).forEach(c=>{map[c.play_id]=c})
    setPlays(playRows||[]); setCharts(map); setStatus(`Loaded ${playRows?.length||0} plays.`)
  }

  async function handleFile(e){
    const file=e.target.files?.[0]; if(!file) return
    setStatus('Reading file...')
    try{
      const rows = await readRows(file)
      if(!rows.length){setStatus('No rows found.'); return}
      const name = prompt('Project name?', file.name.replace(/\.[^.]+$/,'')) || file.name
      const p = await createProject(name,file.name,rows)
      await selectProject(p)
      setStatus(`Imported ${rows.length} plays.`)
    }catch(err){setStatus('Import failed: '+err.message)}
  }

  function readRows(file){
    return new Promise((resolve,reject)=>{
      if(file.name.toLowerCase().endsWith('.csv')){
        Papa.parse(file,{header:true,skipEmptyLines:true,complete:r=>resolve(r.data),error:reject})
      }else{
        const reader=new FileReader()
        reader.onload=()=>{try{const wb=XLSX.read(reader.result,{type:'array'}); const ws=wb.Sheets[wb.SheetNames[0]]; resolve(XLSX.utils.sheet_to_json(ws,{defval:''}))}catch(e){reject(e)}}
        reader.onerror=reject; reader.readAsArrayBuffer(file)
      }
    })
  }

  async function createProject(name, filename, rows){
    if(!supabaseEnabled){
      const p={id:crypto.randomUUID(),name,source_filename:filename,created_at:new Date().toISOString()}
      const ps=[p,...projects]; localStorage.setItem('fp_projects',JSON.stringify(ps)); setProjects(ps)
      const playRows=rows.map((r,i)=>({id:crypto.randomUUID(),project_id:p.id,row_index:i,play_key:playKey(r,i),raw:r,pff_offteam:norm(r,'pff_OFFTEAM'),pff_defteam:norm(r,'pff_DEFTEAM'),pff_gameid:norm(r,'pff_GAMEID'),pff_playid:norm(r,'pff_PLAYID'),pff_gsisplayid:norm(r,'pff_GSISPLAYID'),pff_sortorder:norm(r,'pff_SORTORDER'),pff_week:norm(r,'pff_WEEK')}))
      localStorage.setItem('fp_'+p.id,JSON.stringify({plays:playRows,charts:{}})); return p
    }
    const {data:p,error:e}=await supabase.from('projects').insert({name,source_filename:filename}).select().single()
    if(e) throw e
    const playRows=rows.map((r,i)=>({project_id:p.id,row_index:i,play_key:playKey(r,i),raw:r,pff_offteam:norm(r,'pff_OFFTEAM'),pff_defteam:norm(r,'pff_DEFTEAM'),pff_gameid:norm(r,'pff_GAMEID'),pff_playid:norm(r,'pff_PLAYID'),pff_gsisplayid:norm(r,'pff_GSISPLAYID'),pff_sortorder:norm(r,'pff_SORTORDER'),pff_week:norm(r,'pff_WEEK')}))
    for(let i=0;i<playRows.length;i+=500){ const {error}=await supabase.from('plays').insert(playRows.slice(i,i+500)); if(error) throw error }
    await loadProjects(); return p
  }

  const filtered = useMemo(()=>{
    if(!filterTeam) return plays
    return plays.filter(p=> filterMode==='offense' ? p.pff_offteam===filterTeam : filterMode==='defense' ? p.pff_defteam===filterTeam : (p.pff_offteam===filterTeam || p.pff_defteam===filterTeam))
  },[plays,filterTeam,filterMode])
  const teams = useMemo(()=>Array.from(new Set(plays.flatMap(p=>[p.pff_offteam,p.pff_defteam]).filter(Boolean))).sort(),[plays])
  const current = filtered[Math.min(idx, Math.max(0,filtered.length-1))]
  const chart = current ? charts[current.id] || {} : {}

  useEffect(()=>{ if(current){ setFormation(chart.chart_formation||''); setFzAdv(chart.fz_advantage||''); setFzAtk(chart.fz_attacked||'') } },[current?.id])

  async function savePatch(patch){
    if(!current) return
    const next={...chart,...patch,play_id:current.id,project_id:project.id}
    setCharts({...charts,[current.id]:next})
    if(!supabaseEnabled){
      const local=JSON.parse(localStorage.getItem('fp_'+project.id)||'{}'); local.charts={...(local.charts||{}),[current.id]:next}; localStorage.setItem('fp_'+project.id,JSON.stringify(local)); return
    }
    const {error}=await supabase.from('charted_plays').upsert({play_id:current.id,project_id:project.id,chart_formation:next.chart_formation||null,fz_advantage:next.fz_advantage||null,fz_attacked:next.fz_attacked||null,flagged:!!next.flagged,skipped:!!next.skipped,notes:next.notes||null,updated_at:new Date().toISOString()},{onConflict:'play_id'})
    if(error) setStatus(error.message)
  }
  async function chooseAdv(v){ setFzAdv(v); await savePatch({fz_advantage:v}); if(fzAtk) nextPlaySoon() }
  async function chooseAtk(v){ setFzAtk(v); await savePatch({fz_attacked:v}); if(fzAdv) nextPlaySoon() }
  function nextPlaySoon(){ setTimeout(()=>setIdx(i=>Math.min(i+1,filtered.length-1)),120) }
  function addFormToken(t){
    let s=formation.trim()
    if(FORM_BASES.includes(t)) s = s ? `${s}${t}` : t
    else if(t==='B') s = s ? `${s}B` : 'B'
    else if(t==='T'||t==='TT') s = t + s.replace(/^T{1,2}/,'')
    else s = s ? `${s} ${t}` : t
    setFormation(s); savePatch({chart_formation:s})
  }
  function clearFormation(){setFormation('');savePatch({chart_formation:null})}
  function nextBlank(){ const n=filtered.findIndex((p,i)=>i>=idx && !(charts[p.id]?.fz_advantage && charts[p.id]?.fz_attacked)); setIdx(n>=0?n:0) }
  function exportCsv(){
    if(!plays.length) return
    const rawKeys=Array.from(new Set(plays.flatMap(p=>Object.keys(p.raw||{}))))
    const headers=[...rawKeys,'Chart Formation','FZ Advantage','FZ Attacked','Advantage Attacked','Flagged','Skipped','Notes']
    const lines=[headers.map(csvEscape).join(',')]
    plays.forEach(p=>{const c=charts[p.id]||{}; const aa=c.fz_advantage&&c.fz_attacked&&c.fz_advantage===c.fz_attacked?1:0; lines.push([...rawKeys.map(k=>p.raw[k]),c.chart_formation||'',c.fz_advantage||'',c.fz_attacked||'',aa,c.flagged?1:0,c.skipped?1:0,c.notes||''].map(csvEscape).join(','))})
    const blob=new Blob([lines.join('\n')],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=(project?.name||'charted')+'_export.csv'; a.click()
  }

  if(!project) return <div className="page"><h1>Football Analytics Platform v1</h1><p className="status">{status}</p><label className="upload">Import PFF CSV/XLSX<input type="file" accept=".csv,.xlsx,.xls" onChange={handleFile}/></label><h2>Projects</h2>{projects.map(p=><button className="project" key={p.id} onClick={()=>selectProject(p)}>{p.name}<span>{p.source_filename}</span></button>)}</div>

  return <div className="page"><header><button onClick={()=>setProject(null)}>Projects</button><div><b>{project.name}</b><small>{filtered.length} plays shown / {plays.length} total</small></div><button onClick={exportCsv}>Export CSV</button></header><p className="status">{status}</p><section className="filters"><select value={filterTeam} onChange={e=>{setFilterTeam(e.target.value);setIdx(0)}}><option value="">All teams</option>{teams.map(t=><option key={t} value={t}>{t}</option>)}</select><select value={filterMode} onChange={e=>{setFilterMode(e.target.value);setIdx(0)}}><option value="either">Either side</option><option value="offense">Offense only</option><option value="defense">Defense only</option></select><button onClick={nextBlank}>Next blank</button><input type="number" min="1" max={filtered.length} value={idx+1} onChange={e=>setIdx(Math.max(0,Math.min(filtered.length-1,Number(e.target.value)-1)))} /></section>{current && <main><div className="card"><div className="playnum">Play {idx+1} / {filtered.length}</div><div className="meta">OFF {current.pff_offteam||'-'} vs DEF {current.pff_defteam||'-'} | Week {current.pff_week||'-'} | Code {current.play_key}</div><pre>{PFF_KEYS.map(k=>`${k}: ${norm(current.raw,k)}`).join('\n')}</pre></div><div className="card"><h3>Formation: {formation||'blank'}</h3><div className="grid small">{['T','TT','B',...FORM_BASES,'WS','WW','DT','DW'].map(t=><button key={t} onClick={()=>addFormToken(t)}>{t}</button>)}</div><button onClick={clearFormation}>Clear formation</button></div><div className="card"><h3>FZ Advantage</h3><div className="grid">{ZONES.map(z=><button className={fzAdv===z?'sel':''} key={z} onClick={()=>chooseAdv(z)}>{z}</button>)}</div></div><div className="card"><h3>FZ Attacked</h3><div className="grid">{ZONES.map(z=><button className={fzAtk===z?'sel':''} key={z} onClick={()=>chooseAtk(z)}>{z}</button>)}</div><div className="result">Advantage attacked: {fzAdv&&fzAtk&&fzAdv===fzAtk?'1 / Yes':'0 / No'}</div></div><div className="nav"><button onClick={()=>setIdx(Math.max(0,idx-1))}>Previous</button><button onClick={()=>savePatch({flagged:!chart.flagged})}>{chart.flagged?'Unflag':'Flag'}</button><button onClick={()=>savePatch({skipped:true}).then(()=>setIdx(Math.min(idx+1,filtered.length-1)))}>Skip</button><button onClick={()=>setIdx(Math.min(idx+1,filtered.length-1))}>Next</button></div></main>}</div>
}

createRoot(document.getElementById('root')).render(<App />)
